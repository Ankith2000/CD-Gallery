package com.nttdatatraining.main;

import com.nttdatatraining.dao.AdminDaoImpl;
import com.nttdatatraining.dao.CustomerDao;
import com.nttdatatraining.dao.CustomerDaoImpl;
import com.nttdatatraining.dto.Admin;
import com.nttdatatraining.dto.Album;
import com.nttdatatraining.dto.AlbumCategory;
import com.nttdatatraining.dto.Customer;
import com.nttdatatraining.dto.RentalDetails;
import java.util.List;
import java.util.Scanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * MyMain - This class contains the driver code.
 */

public class MyMain {
  
  //Created LoggerFactory object to log error messages.
  private static final Logger LOGGER = LoggerFactory.getLogger(MyMain.class);
  
  private static String customerID = "";

  /**
  * Main - Main method of the class.
  */
  public static void main(String[] args) {

    AdminDaoImpl adminDao = new AdminDaoImpl();
    CustomerDaoImpl customerDao = new CustomerDaoImpl();
    // Created a variable and initialize for the switch case.
    Scanner sc = new Scanner(System.in);
    int c;

    // OUTERLOOP - Loop to create interface menu.
    OUTERLOOP: do {
      System.out.println("Welcome to CD Gallery!!!");
      System.out.println("Enter 1 for Admin Login");
      System.out.println("Enter 2 for Customer Login");
      System.out.println("Enter 3 for Customer Registration");
      System.out.println("Enter 4 to Exit");
      c = sc.nextInt();
      // try block implemented
      try {
        switch (c) {
          // Interface for admin login.
          case 1:

			Admin admin = new Admin();
			System.out.println("Enter Username :");
			admin.setAdminId(sc.next());
			System.out.println("Enter Password :");
			admin.setPassword(sc.next());
			boolean status = adminDao.adminLogin(admin);
			if (status == true) {
				System.out.println("Login Success!!!, Welcome " + admin.getAdminId());
				LOGGER.info("Login by " + admin.getAdminId());
				MyMain.admin();
			} 
			else 
			{
				LOGGER.warn("Invalid Credentials for Admin");
			}
			break;

			// Interface for customer login.
			case 2:
				
				Customer customer = new Customer();
				sc.nextLine();
				System.out.println("Enter Username :");
				customerID = sc.nextLine();
				customer.setCustomerId(customerID);
				System.out.println("Enter Password :");
				customer.setPassword(sc.next());
				status = customerDao.customerLogin(customer);
				if (status == true) {
					MyMain.customer();
					LOGGER.info("Login by Customer" + customer.getCustomerId());
				} 
				else {
					//System.out.println("invalid credentials");
					LOGGER.warn("Invalid Credentials for Customer");
				}
				break;
				
			// Interface for customer registration.	
			case 3:
				Customer cust = new Customer();
				CustomerDao cus = new CustomerDaoImpl();
				sc.nextLine();
				System.out.println("Create Username : ");
				cust.setCustomerId(sc.nextLine());
				
				System.out.println("Create Password : ");
				cust.setPassword(sc.nextLine());
				System.out.println("Enter First Name : ");
				cust.setFirstName(sc.nextLine());
				System.out.println("Enter Second Name : ");
				cust.setSecondName(sc.nextLine());
				System.out.println("Enter Date of Birth in (YYYY-MM-DD) Format : ");
				cust.setDateOfBirth(sc.nextLine());
				System.out.println("Enter Address : ");
				cust.setAddress(sc.nextLine());
				System.out.println("Enter your Mobile Number : ");
				cust.setContactNumber(sc.nextLine());
				System.out.println("Enter credit card number : ");
				cust.setCreditCardNumber(sc.nextLine());
				System.out.println("Enter credit card type : ");
				cust.setCreditCardType(sc.nextLine());
				System.out.println("Enter credit card expire date : ");
				cust.setCreditCardExpiry(sc.nextLine());
				
				cus.addCustomer(cust);
				break;
				
			// End the program. 
			case 4:
				break OUTERLOOP;
			
			// Enter the valid option for switch case.
			default:
				System.out.println("Please enter Valid Option!!!\n");
				
			}
		}	
			
		// try block implemented
		catch (Exception e) {
			LOGGER.error("Exception occurs" + e.getMessage());
		}
		} while (c != 4);

	}
	
	// Method for admin operations.
	public static void admin() {
		AdminDaoImpl adminDao = new AdminDaoImpl();
		int choice = 0;
		Scanner sc = new Scanner(System.in);
		// Loop for admin operations.
		LOOP: do {
			try {
				System.out.println("Enter 1 to add albums : ");
				System.out.println("Enter 2 to view all albums : ");
				System.out.println("Enter 3 to view all the available albums : ");
				System.out.println("Enter 4 to view all rental details : ");
				System.out.println("Enter 5 to exit : ");
				choice = sc.nextInt();

				switch (choice) {
					case 1:
						
						// Created album object.
						Album album = new Album();
						sc.nextLine();
						System.out.println("Enter the Album Name :");
						album.setAlbumTitle(sc.nextLine());
						System.out.println("Enter the Hire Price :");
						album.setHirePrice(sc.nextInt());
						System.out.println("Enter the Number of CDs available :");
						album.setNumberOfCds(sc.nextInt());
						System.out.println("Enter the Status :");
						album.setStatus(sc.nextInt());	
						System.out.println("Enter the Category ID :");
						album.setCategoryId(sc.nextInt());

						adminDao.addAlbum(album);
						break;
					case 2:
						
						// Displaying album.
						List<Album> albumDisplay = adminDao.displayAlbum();
						if(albumDisplay.size() > 0)
						{	
							for(Album a : albumDisplay)
							{
								System.out.println("Album ID : " + a.getAlbumId() +
										" , Album Name : " + a.getAlbumTitle() + 
										" , Hire Price : " + a.getHirePrice() + 
										", Number of CDs available : " + a.getNumberOfCds() +
										", Category ID :" + a.getCategoryId());
							}
						}
						else
							System.out.println("No records found in Album");
						
						break;
						//adminDao.displayAlbum();
					case 3:
						
						// Displaying available album.
						List<Album> albumAvailableDisplay = adminDao.displayAvailableAlbum();
						if(albumAvailableDisplay.size() > 0)
						{	
							for(Album a : albumAvailableDisplay)
							{
								System.out.println("Album ID : " + a.getAlbumId() +
										" , Album Name : " + a.getAlbumTitle() + 
										" , Hire Price : " + a.getHirePrice() + 
										", Number of CDs available : " + a.getNumberOfCds() +
										", Category ID :" + a.getCategoryId());
							}
						}
						else
							System.out.println("No records found in Album");
						
						break;
						//adminDao.displayAvailableAlbum();
					case 4:
						
						// Displaying rental details.
						//adminDao.displayRentalDetails();
						
						List<RentalDetails> rental = adminDao.displayRentalDetails();
						if(rental.size() > 0)
						{	
							for(RentalDetails r : rental)
							{
								System.out.println("Hire ID : " + r.getHiredId() +
										" , Customer ID : " + r.getCustomerId() + 
										" , Album ID : " + r.getAlbumId() +
										" , Number of CDs Hired : " + r.getCdsHired() + 
										" , Hiring Date : " + r.getHireDate() + 
										" , Return Date : " + r.getReturnDate() +
										" , Return Status : " + r.getStatus() +
										" , Total Hire Price : " + r.getTotalHirePrice());
							}
						}
						else
							System.out.println("No records found in Rental Details");
						
						break;
						
					case 5:
						// Exit loop.
						break LOOP;
				}
			} 
			
			// Implementing catch block.
			catch (Exception e) {
				//e.printStackTrace();
	    		LOGGER.error("Exception in Admin operations" + e.getMessage());
	    		sc.nextInt();
	    	}
		} while (choice != 5);

	}

	// Created method for customer.
	public static void customer() {
		AdminDaoImpl adminDao = new AdminDaoImpl();
		CustomerDaoImpl customerDao = new CustomerDaoImpl();
		int choice = 0;
		Customer cust = new Customer();
		cust.setCustomerId(customerID);
		Scanner sc = new Scanner(System.in);
		
		
		//Creating object for album category.
		AlbumCategory albumcategory = new AlbumCategory();
		Album album = new Album();
		
		/**
		 * LOOP - Loop for customer operations.
		 */
		LOOP: do {
			try {
				System.out.println("Enter 1 to Search Category : ");
				System.out.println("Enter 2 to Search Albums : ");
				System.out.println("Enter 3 to Book an Album : ");
				System.out.println("Enter 4 to view Booked Album : ");
				System.out.println("Enter 5 to Return Album : ");
				System.out.println("Enter 6 to Exit : ");
				choice = sc.nextInt();

				switch (choice) {
					case 1:
						albumcategory = new AlbumCategory();
						System.out.println("Enter 1 for Pop");
						System.out.println("Enter 2 for Rock");
						System.out.println("Enter 3 for Jazz");
						System.out.println("Enter 4 for Classical");
						System.out.println("Enter 5 for Hip Hop");
						System.out.println("Enter 6 for Disco");
						System.out.println("Enter the Album ID :");
						albumcategory.setCategoryId(sc.nextInt());
						//							sc.nextLine();
						//							System.out.println("Enter the Album Name :");
						//							album.setCategoryName(sc.nextLine());

						//customerDao.SearchAlbumCategory(albumcategory);
						List<AlbumCategory> albumcat = customerDao.searchAlbumCategory(albumcategory);
						if(albumcat.size() > 0)
						{	
							for(AlbumCategory a : albumcat)
							{
								System.out.println("Category Name : " + a.getCategoryName() +
										"\nDescription : " + a.getCategoryDesc());	
							}
						}
						else
							System.out.println("No records found in Album Category");
						
						break;
					case 2:					
						album = new Album();
						sc.nextLine();
						System.out.println("Enter the name of the album : ");
						album.setAlbumTitle(sc.nextLine());

						//customerDao.SearchAlbum(album);
						List<Album> albumlist = customerDao.searchAlbum(album);
						if(albumlist.size() > 0)
						{	
							for(Album a : albumlist)
							{
								System.out.println("Album ID : " + a.getAlbumId() +
										", Album Name : " + a.getAlbumTitle() +
										", Hire Price : " + a.getHirePrice() + 
										", Available CDs : " + a.getNumberOfCds() +
										", Status : " + a.getStatus() +
										", Category ID : " + a.getCategoryId());	
							}
						}
						else
							System.out.println("No records found in Album Category");
						break;
					case 3:
						System.out.println("Available Album!\n");
						List<Album> albumAvailableDisplay = adminDao.displayAvailableAlbum();
						if(albumAvailableDisplay.size() > 0)
						{	
							for(Album a : albumAvailableDisplay)
							{
								System.out.println("Album ID : " + a.getAlbumId() +
										" , Album Name : " + a.getAlbumTitle() + 
										" , Hire Price : " + a.getHirePrice() + 
										", Number of CDs available : " + a.getNumberOfCds() +
										", Category ID :" + a.getCategoryId());
							}
						}
						else
							System.out.println("No records found in Album");
						album = new Album();
						System.out.println("Enter the Album ID which has to be Booked");
						album.setAlbumId(sc.nextInt());
						System.out.println("Enter number of cds to be hired : ");
						album.setNumberOfCds(sc.nextInt());
						customerDao.bookAlbum(cust, album);

						break;
					case 4:
						//customerDao.viewBookedAlbum(cust);
						RentalDetails rental = new RentalDetails();
						List<RentalDetails> viewbooked;// = customerDao.viewBookedAlbum(cust);
						System.out.println("Enter which details should be shown\n1. To be returned\n2. Returned");
						int innerchoice = sc.nextInt();
						//rental.setStatus();
						if(innerchoice == 1)
						{
							rental.setStatus("No");
							viewbooked = customerDao.viewBookedAlbum(cust,rental);
						}
						else
						{
							rental.setStatus("Yes");
							viewbooked = customerDao.viewBookedAlbum(cust,rental);
						}
							
						
						if(viewbooked.size() > 0)
						{	
							for(RentalDetails r : viewbooked)
							{
								System.out.println("Hire ID : " + r.getHiredId() +
										", Customer ID : " + r.getCustomerId() +
										", Album ID : " + r.getAlbumId() +
										", Number of CDs hired : " + r.getCdsHired() +
										", Hire Date : " + r.getHireDate() +
										", Return Date : " + r.getReturnDate() +
										", Return Status : " + r.getStatus() +
										", Total Hired Price : " + r.getTotalHirePrice());
							}
						}
						else
							System.out.println("No records found in Rental Details");
						break;
					case 5:
						RentalDetails rentaldetails = new RentalDetails();
						System.out.println("Enter Hire ID which you want to return : ");
						rentaldetails.setHiredId(sc.nextInt());
						System.out.println(customerDao.returnAlbum(cust, rentaldetails));
						break;

					case 6:
						
						// Exit the loop.
						break LOOP;
				}
			} 
			
			// Catch block implemented.
			catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception");
	    		LOGGER.error("CustomInputMismatchException occurs in DisplayAvailableAlbum()");
	    		//throw new CustomSQLException("InputMismatchException Exception Occurs");
			}
		} while (choice != 6);
	}
}
