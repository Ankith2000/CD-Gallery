package com.nttdatatraining.dao;

import com.nttdatatraining.dto.Admin;
import com.nttdatatraining.dto.Album;
import com.nttdatatraining.dto.RentalDetails;
import java.util.List;

/**
 * AdminDao - This interface contains the AdminDao details.
 *
 * @author CDGallery.
 *
 */
public interface AdminDao {

  boolean adminLogin(Admin admin) throws DaoException;

  boolean addAlbum(Album album) throws DaoException;
  
  List<Album> displayAvailableAlbum() throws DaoException;
  
  List<Album> displayAlbum() throws DaoException;
  
  List<RentalDetails> displayRentalDetails() throws DaoException;
}
