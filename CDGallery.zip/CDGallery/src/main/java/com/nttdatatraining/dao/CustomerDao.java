package com.nttdatatraining.dao;

import java.util.List;

import com.nttdatatraining.dto.Album;
import com.nttdatatraining.dto.AlbumCategory;
import com.nttdatatraining.dto.Customer;
import com.nttdatatraining.dto.RentalDetails;

/**
 * CustomerDao - This interface contains the CustomerDao Details.
 *
 * @author CDGallery.
 *
 */
public interface CustomerDao {

  boolean customerLogin(Customer customer) throws DaoException;
  List<Album> searchAlbum(Album album) throws DaoException;
  List<AlbumCategory> searchAlbumCategory(AlbumCategory albumcategory) throws DaoException;
  boolean bookAlbum(Customer cust, Album album) throws DaoException;
  List<RentalDetails> viewBookedAlbum(Customer cust, RentalDetails rental) throws DaoException;
  int returnAlbum(Customer cust, RentalDetails rental) throws DaoException;
  boolean addCustomer(Customer cust) throws DaoException;
}
