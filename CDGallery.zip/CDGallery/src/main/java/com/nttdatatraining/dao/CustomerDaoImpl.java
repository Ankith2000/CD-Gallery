package com.nttdatatraining.dao;

import com.nttdatatraining.connection.DbConnection;
import com.nttdatatraining.connection.DbPooledConnection;
import com.nttdatatraining.dto.Album;
import com.nttdatatraining.dto.AlbumCategory;
import com.nttdatatraining.dto.Customer;
import com.nttdatatraining.dto.RentalDetails;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * CustomerDao - This class contains the CustomerDao details.
 *
 */
public class CustomerDaoImpl implements CustomerDao {

  // Created object of scanner class to take input from user.
  Scanner sc = new Scanner(System.in);

  // Created LoggerFactory object to log error messages.
  private static final Logger LOGGER = LoggerFactory.getLogger(CustomerDaoImpl.class);

  /**
   * customerLogin - method for validating customer login.
   *
   * @param customer - it has customer as a parameter.
   * @return boolean
   */
  @Override
  public boolean customerLogin(Customer customer) {
    boolean status = false;
    String firstname;
    String secondname;
    try (Connection con = DbConnection.getDatabaseConnection())  {
      PreparedStatement pst  = con.prepareStatement("select customerid,password,"
          + "firstname,secondname "
          + "from customer  where customerid  = ? and password = ?");
            
      pst.setString(1, customer.getCustomerId());
      pst.setString(2, customer.getPassword());
           
      ResultSet rs = pst.executeQuery();
      if (rs.next()) {
        firstname = rs.getString(3);
        secondname = rs.getString(4);
        LOGGER.info("Login Success!!! by " + firstname + " " + secondname);
        System.out.println("Login Success!!!, Welcome " + firstname + " " + secondname);
        status = true;
      }
      rs.close();           
    } catch (SQLException e) {
      LOGGER.error("Exception occurs in CustomerLogin()" + e.getMessage());
    }
    return status;
  }

  /**
 * displayAlbumCategory - Method to display album category.
 */
  public List<AlbumCategory> displayAlbumCategory() {
    List<AlbumCategory> list = new ArrayList<>();

    // Creating database connection.
    try (Connection con = DbPooledConnection.getDatabaseConnection()) {
      Statement st = con.createStatement();

      ResultSet rs = st.executeQuery("select * from albumcategory");
      if (rs.isBeforeFirst()) {
        if (rs.next()) {
          AlbumCategory albumcat = new AlbumCategory();
          albumcat.setCategoryId(rs.getInt("categoryid"));
          albumcat.setCategoryName(rs.getString("categoryname"));
          albumcat.setCategoryDesc(rs.getString("categorydesc"));
          list.add(albumcat);
          
        }
        LOGGER.info("Album Category Displayed");
      } else {
        System.out.println("No records found in the table");
        LOGGER.warn("Album Category Displayed");
      }

    } catch (SQLException e) {

      LOGGER.error("Exception occurs in DisplayAlbumCategory()" + e.getMessage());
    }
    return list;
  }

  /**
 * searchAlbumCategory - Method for customer to search albums categories.
 * 
 */
  public List<AlbumCategory> searchAlbumCategory(AlbumCategory albumcategory) {
    List<AlbumCategory> list = new ArrayList<>();

    try (Connection con = DbConnection.getDatabaseConnection())  {

      PreparedStatement pst = 
          con.prepareStatement("select * from albumcategory where categoryid = ?");
      pst.setInt(1, albumcategory.getCategoryId());

      ResultSet rs = pst.executeQuery();
      if (rs.isBeforeFirst()) {
        while (rs.next()) {
          AlbumCategory albumCategory = new AlbumCategory();
          albumCategory.setCategoryName(rs.getString("categoryname"));
          albumCategory.setCategoryDesc(rs.getString("categorydesc"));
          list.add(albumCategory);
          
        } 
      } else {
        System.out.println("No records found in the table");
      }
    } catch (SQLException e) {
      LOGGER.error("Exception occurs in SearchAlbumCategory()" + e.getMessage());
    }
    return list;
  }
  /**
  *  searchAlbum -  Method for customer to search albums.
  *
  *@param album - it has album as a parameter.
  */
  
  public List<Album> searchAlbum(Album album) {
    List<Album> list = new ArrayList<>();
    //Creating connection to database.
    try (Connection con = DbConnection.getDatabaseConnection())  {
      PreparedStatement pst = 
          con.prepareStatement("select * from album where albumid = ?;");
      pst.setInt(1, album.getAlbumId());
      ResultSet rs = pst.executeQuery();
      if (rs.isBeforeFirst()) {
        while (rs.next()) {
          Album album1 = new Album();
          album1.setAlbumId(rs.getInt("albumid"));
          album1.setAlbumTitle(rs.getString("albumtitle"));
          album1.setHirePrice(rs.getInt("hireprice"));
          album1.setNumberOfCds(rs.getInt("numberofcds"));
          album1.setStatus(rs.getInt("status"));
          album1.setCategoryId(rs.getInt("categoryid"));
          list.add(album1);
        } 
      } else {
        System.out.println("No records found in the table");
      }
    } catch (SQLException e) {
      LOGGER.error("Exception occurs in SearchAlbum()" + e.getMessage());
    }
    return list;
  }
  /**
  * addCustomer - Method for new customer registration operation.
  *
  *@param cust - it has cust as a parameter.
  * @return boolean.
  */
  
  public boolean addCustomer(Customer cust) {
    boolean status = false;
    try (Connection con = DbConnection.getDatabaseConnection()) {
      PreparedStatement pst = 
          con.prepareStatement("insert into customer "
          + "values(?,?,?,?,?,?,?,?,?,?)");
      pst.setString(1, cust.getCustomerId());
      pst.setString(2, cust.getPassword());
      pst.setString(3, cust.getFirstName());
      pst.setString(4, cust.getSecondName());
      pst.setString(5, cust.getDateOfBirth());
      pst.setString(6, cust.getAddress());
      pst.setString(7, cust.getContactNumber());
      pst.setString(8, cust.getCreditCardNumber());
      pst.setString(9, cust.getCreditCardType());
      pst.setString(10, cust.getCreditCardExpiry());
      System.out.println(pst);
      pst.executeUpdate();
      System.out.println("Record added Successfully!!!");
      status = true;
    } catch (SQLException e) {
      LOGGER.error("Exception occurs in AddCustomer()" + e.getMessage());
    }
    return status;
  }
  /**
  * bookAlbum - method for customer to book albums.
  *
  * @param album - it has album as parameter.
  * 
  * @param cust - it has cust as parameter.
  */
  
  public boolean bookAlbum(Customer cust, Album album) {
    boolean status = false;
    int numberofcds;
    int hp;
    int stat;

    // Creating connection to database.
    try (Connection con = DbPooledConnection.getDatabaseConnection())  {
      PreparedStatement pst  = con.prepareStatement("select hireprice,numberofcds,status "
          + "from album where albumid  = ?");

      pst.setInt(1, album.getAlbumId());
      ResultSet rs = pst.executeQuery();

      rs.next();
      stat = rs.getInt(3);
      if (stat == 0) {
        System.out.println("CD is not available!!!");
        return status;
      }
      hp = rs.getInt(1);
      numberofcds = rs.getInt(2);

      rs.close();
      PreparedStatement pst1  = con.prepareStatement("insert into rentaldetails(customerid, "
          + "albumid, "
          + "cdshired, hiredate, returndate, status, totalhireprice)"
          + "values (?,?,?,?,?,?,?)");
      pst1.setString(1, cust.getCustomerId());
      pst1.setInt(2, album.getAlbumId());
      pst1.setInt(3, album.getNumberOfCds());
      if (numberofcds < album.getNumberOfCds()) {
        System.out.println("Only " + numberofcds + " CDs available");
        LOGGER.warn("Only" + numberofcds + "CDs available");
        return status;
      }
      pst1.setString(4, LocalDate.now().toString());
      pst1.setString(5, null);
      pst1.setString(6, "No");
      pst1.setInt(7, album.getNumberOfCds() * hp);
      pst1.executeUpdate();

      PreparedStatement pst2  = con.prepareStatement("update album set numberofcds=numberofcds-?"
           + " where albumid=?;");
      //+ "update album set status=0 where numberofcds=0");
      pst2.setInt(1, album.getNumberOfCds());
      pst2.setInt(2, album.getAlbumId());
      pst2.executeUpdate();
      PreparedStatement pst3 = con.prepareStatement("update album set status=0 where "
          + "numberofcds=0 and albumid = ?");
      pst3.setInt(1, album.getAlbumId());
      pst3.executeUpdate();
      status = true;
      System.out.println("Booking Successfull");
    } catch (SQLException e) {

      LOGGER.error("Exception occurs in BookAlbum()" + e.getMessage());
    }
    return status;
  }
  /**
   * viewBookedAlbum - Method for customer to view booked albums.
   *
   * @param cust - it has cust as a parameter.
   * 
   * @param rental - it has rental as a parameter.
   */
  
  public List<RentalDetails> viewBookedAlbum(Customer cust, RentalDetails rental) {
    List<RentalDetails> list = new ArrayList<>();
    //Creating connection to database.
    try (Connection con = DbConnection.getDatabaseConnection()) {
      PreparedStatement pst = 
          con.prepareStatement("select * from rentaldetails where customerid = ? and status = ?;");
      pst.setString(1, cust.getCustomerId());
      pst.setString(2, rental.getStatus());
      ResultSet rs = pst.executeQuery();
      if (rs.isBeforeFirst()) {
        while (rs.next()) {
          RentalDetails rent = new RentalDetails();
          rent.setHiredId(rs.getInt("hiredid"));
          rent.setCustomerId(rs.getString("customerid"));
          rent.setAlbumId(rs.getInt("albumid"));
          rent.setCdsHired(rs.getInt("cdshired"));
          rent.setHireDate(rs.getString("hiredate"));
          rent.setReturnDate(rs.getString("returndate"));
          rent.setStatus(rs.getString("status"));
          rent.setTotalHirePrice(rs.getInt("totalhireprice"));
          list.add(rent);
          
        }
      } else {
        System.out.println("No records found in the table");
      }
    } catch (SQLException e) {
      LOGGER.error("Exception occurs in ViewBookedAlbum()" + e.getMessage());
    }
    return list;
  }

  /**
  *returnAlbum - This contains method for return album.
  *
  * @param cust - it has cust as a parameter.
  * 
  * @param rental - it has rental as a parameter too.
  * @return int
  */
  public int returnAlbum(Customer cust, RentalDetails rental) {

    //Creating connection to database.
    try (Connection con = DbConnection.getDatabaseConnection())  {
      
      PreparedStatement pst = con.prepareStatement("update album t1, "
          + "rentaldetails t2 set "
          + "t1.status = 1, t1.numberofcds = t1.numberofcds + t2.cdshired, "
          + "t2.returndate = (select current_date()), t2.status='Yes' "
          + "where t2.hiredid = ? and t1.albumid = t2.albumid and t2.customerid= ? "
          + "and t2.status = 'No';");
      pst.setInt(1, rental.getHiredId());
      pst.setString(2, cust.getCustomerId());
      CustomerDaoImpl.displayHirePrice(cust, rental);
      pst.execute();
    } catch (SQLException e) {
      LOGGER.error("Exception occurs in ReturnAlbum()" + e.getMessage());
    }
    return CustomerDaoImpl.displayHirePrice(cust, rental);
  }

  /**
 * displayHirePrice - Method to calculate total rental price. 
 *
 *@param cust - it has cust as a parameter.
 *
 * @param rental - it has rental as a parameter.
 */
  public static int displayHirePrice(Customer cust, RentalDetails rental) {

    // Creating connection to database.
    try (Connection con = DbConnection.getDatabaseConnection())  {
      PreparedStatement pst  = con.prepareStatement("select totalhireprice from rentaldetails "
          + "where hiredid = ? and customerid= ?;");

      pst.setInt(1, rental.getHiredId());
      pst.setString(2, cust.getCustomerId());

      ResultSet rs = pst.executeQuery();
      if (rs.next()) {
        //System.out.println("Total Hired Price :" + rs.getString(1));
        LOGGER.info("Total Hired price displayed"); 
        return rs.getInt(1);
      }
      rs.close();
    } catch (SQLException e) {
      LOGGER.error("Exception occurs in DisplayHirePrice()" + e.getMessage());
    }
    return 0;
  }
}