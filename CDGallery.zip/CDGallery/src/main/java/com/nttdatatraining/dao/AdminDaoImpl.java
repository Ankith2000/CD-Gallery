package com.nttdatatraining.dao;

import com.nttdatatraining.connection.DbConnection;
import com.nttdatatraining.dto.Admin;
import com.nttdatatraining.dto.Album;
import com.nttdatatraining.dto.RentalDetails;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * AdminDao - This class contains the AdminDAO details.
 *
 */

public class AdminDaoImpl implements AdminDao {
  // Created LoggerFactory object to log error messages.
  private static final Logger LOGGER = LoggerFactory.getLogger(AdminDao.class);
    
  /**
* This method validates admin for login.
*
* @param admin - method adminLogin has single parameter admin.
* @return boolean
*/
  @Override
  public boolean adminLogin(Admin admin) {
                    
    boolean status = false;

    // Creating connection to database.
    try (Connection con = DbConnection.getDatabaseConnection()) {
      PreparedStatement pt = con.prepareStatement("select * from admin where adminid = ? "
          + "and password = ?");

      pt.setString(1, admin.getAdminId());
      pt.setString(2, admin.getPassword());
      ResultSet rs = pt.executeQuery();
      
      if (rs.isBeforeFirst()) {
        status = true;
        LOGGER.info("Login by " + admin.getAdminId());
        return status;
      }
      LOGGER.info("Invalid credentials!!!"); 
    
    } catch (SQLException e) {
      LOGGER.error("Exception occurs in adminLogin()" + e.getMessage());
    }
    return status;
  }
        
  /**
   * displayAlbum - Method for displayAlbum details.
   *
   */
  @Override
  public List<Album> displayAlbum() {
    List<Album> list = new ArrayList<>();
    // Creating connection to database.
    try (Connection con = DbConnection.getDatabaseConnection()) {
      Statement st = con.createStatement();

      ResultSet rs = st.executeQuery("select * from album");

      if (rs.isBeforeFirst()) {
        while (rs.next()) {
          Album album = new Album();
          album.setAlbumId(rs.getInt("albumid"));
          album.setAlbumTitle(rs.getString("albumtitle"));
          album.setHirePrice(rs.getInt("hireprice"));
          album.setNumberOfCds(rs.getInt("numberofcds"));
          album.setStatus(rs.getInt("status"));
          album.setCategoryId(rs.getInt("categoryid"));
          list.add(album);
          //System.out.println("Album ID : " + rs.getInt("albumid") +
          //" , Album Name : " + rs.getString("albumtitle") + 
          //" , Hire Price : " + rs.getString("hireprice") + 
          //", Number of CDs available : " + rs.getInt("numberofcds") +
          //", Category ID :" + rs.getInt("categoryid"));
        }
        LOGGER.info("Album displayed");
      
      } else {
        System.out.println("No albums found");
        LOGGER.info("No albums found");
      }
    } catch (SQLException e) {


      LOGGER.error("Exception occurs in DisplayAlbum()" + e.getMessage());
    }
    return list;
  }

  /**
 * displayAvailableAlbum - checking for availability of albums and displaying the same.
 * 
 */
  @Override
  public List<Album> displayAvailableAlbum() {
    List<Album> list = new ArrayList<>();

    // Creating connection to database.
    
    try (Connection con = DbConnection.getDatabaseConnection()) {
      Statement st = con.createStatement();

      ResultSet rs = st.executeQuery("select * from album where status=1");

      if (rs.isBeforeFirst()) {
        while (rs.next()) {
          Album album = new Album();
          album.setAlbumId(rs.getInt("albumid"));
          album.setAlbumTitle(rs.getString("albumtitle"));
          album.setHirePrice(rs.getInt("hireprice"));
          album.setNumberOfCds(rs.getInt("numberofcds"));
          album.setStatus(rs.getInt("status"));
          album.setCategoryId(rs.getInt("categoryid"));
          list.add(album);
          //System.out.println("Album ID : " + rs.getInt("albumid") +
          //" , Album Name : " + rs.getString("albumtitle") + 
          //" , Hire Price : " + rs.getString("hireprice") + 
          //", Number of CDs available : " + rs.getInt("numberofcds") +
          //", Category ID :" + rs.getInt("categoryid"));
          LOGGER.info("Available album displayed");
        }
      }
    } catch (SQLException e) {

      LOGGER.error("Exception occurs in DisplayAvailableAlbum()" + e.getMessage());
    }
    return list;
  }

  /**
   * addAlbum - Method to add new album record.
   *
   *@param album - it has album as parameter.
   * @return boolean.
   */
  @Override
  public boolean addAlbum(Album album) {
    boolean status = false; 
    try (Connection con = DbConnection.getDatabaseConnection()) {
      PreparedStatement pst = con.prepareStatement("insert into album(albumtitle,hireprice,"
          + "numberofcds," + "status,categoryid)" + " " + "values(?,?,?,?,?)");
     
      pst.setString(1, album.getAlbumTitle());
      pst.setInt(2, album.getHirePrice());
      pst.setInt(3, album.getNumberOfCds());
      pst.setInt(4, album.getStatus());
      pst.setInt(5, album.getCategoryId());
      pst.executeUpdate();
      status = true;
      System.out.println("Record added Successfully!!!");
      LOGGER.info("Album Added");
      status = true; 
    } catch (SQLException e) {
      e.printStackTrace();
      LOGGER.error("SQLException occurs in AddAlbum()");
    }
    return status;
  }
 
  /**
 * displayRentalDetails - Method to display rental details to admin.
 */
  @Override
  public List<RentalDetails> displayRentalDetails() {
    List<RentalDetails> list = new ArrayList<>();
    // Creating connection to database.
    try (Connection con = DbConnection.getDatabaseConnection()) {
      Statement st = con.createStatement();
      ResultSet rs = st.executeQuery("select * from rentaldetails");
      if (rs.isBeforeFirst()) {
        while (rs.next()) {
          RentalDetails rental = new RentalDetails();
          rental.setHiredId(rs.getInt("hiredid"));
          rental.setCustomerId(rs.getString("customerid"));
          rental.setAlbumId(rs.getInt("albumid"));
          rental.setCdsHired(rs.getInt("cdshired"));
          rental.setHiredId(rs.getInt("hiredid"));
          rental.setHireDate(rs.getString("hiredate"));
          rental.setReturnDate(rs.getString("returndate"));
          rental.setStatus(rs.getString("status"));
          rental.setTotalHirePrice(rs.getInt("totalhireprice"));
          list.add(rental);
          //System.out.println("Hire ID : " + rs.getInt("hiredid") +
          //" , Customer ID : " + rs.getString("customerid") + " , Album ID : " 
          //+ rs.getInt("albumid") +
          //" , Number of CDs Hired : " + rs.getInt("cdshired") + " , Hiring Date : "
          //+ rs.getString("hiredate") + 
          //" , Return Date : " + rs.getString("returndate") + " , Return Status : "
          //+ rs.getString("status") +
          //" , Total Hire Price : " + rs.getInt("totalhireprice"));
        }
      } else {
        System.out.println("No records found in the table");
      }
    } catch (SQLException e) {
      LOGGER.error("Exception occurs in DisplayRentalDetails()" + e.getMessage());
    }
    return list;
  }
}
