package com.nttdatatraining.dao;

/**
 * DaoException-The DaoException is a custom exception that extends Exception class.
 *
 * @author CDGallery.
 *
 */
public class DaoException extends Exception {
  private static final long serialVersionUID = 1L;
  
  public DaoException() {
    super();
  }

  public DaoException(String arg0) {
    super(arg0);
  }

  public DaoException(Throwable arg0) {
    super(arg0);
  }
}
