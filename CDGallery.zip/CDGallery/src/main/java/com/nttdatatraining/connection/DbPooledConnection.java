package com.nttdatatraining.connection;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbcp.BasicDataSource;

/**
 *  Class for creating database connection.
 *
 */
public class DbPooledConnection {

private static BasicDataSource ds = new BasicDataSource();
	
	static {
        ds.setUrl(DbDetails.CONSTR);
        ds.setUsername(DbDetails.USER_NAME);
        ds.setPassword(DbDetails.PASSWORD);
        ds.setMinIdle(5);
        ds.setMaxIdle(10);
        ds.setMaxOpenPreparedStatements(100);
    }
	
	public static Connection getDatabaseConnection() throws SQLException {
        return ds.getConnection();
    }
    
    private DbPooledConnection() {}
}
