package com.nttdatatraining.connection;

/**
 * DbDetails - This interface contains the Database details.
 *
 * @author CDGallery
 * @since 2021-10-08
 * @version 1.2
 */

public interface DbDetails {

  String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
  String USER_NAME = "root";
  String PASSWORD = "root";
  String CONSTR = "jdbc:mysql://localhost:3306/cdgallerydb?useSSL=false";
}
