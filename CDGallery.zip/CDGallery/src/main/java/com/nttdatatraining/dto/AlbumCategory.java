package com.nttdatatraining.dto;

/**

* Creating member variables of album category class.
*/

public class AlbumCategory {


  private int categoryId;
  private String categoryName;
  private String categoryDesc;
  
  /**
 * Non-parameterized constructor.
 */
  
  public AlbumCategory() {
    super();
  }

  /**
*  Parameterized constructor.
*/
  
  public AlbumCategory(int categoryId, String categoryName, String categoryDesc) {
    super();
    this.categoryId = categoryId;
    this.categoryName = categoryName;
    this.categoryDesc = categoryDesc;
  }

  /**
 
*Getter and setter methods for the member variables.
* 
*/
 
  public int getCategoryId() {
    return categoryId;
  }

  public void setCategoryId(int categoryId) {
    this.categoryId = categoryId;
  }

  public String getCategoryName() {
    return categoryName;
  }

  public void setCategoryName(String categoryName) {
    this.categoryName = categoryName;
  }

  public String getCategoryDesc() {
    return categoryDesc;
  }

  public void setCategoryDesc(String categoryDesc) {
    this.categoryDesc = categoryDesc;
  }
}
