package com.nttdatatraining.dto;

/**

 * Creating member variables of Admin class.
 */

public class Admin {
  private String adminId;
  private String password;
  
  /**
   * Non-parameterized constructor.
   */
  
  public Admin() {
    super();
  }

  /**
 * Parameterized constructor.
 */
  
  public Admin(String adminId, String password) {

    super();
    this.adminId = adminId;
    this.password = password;

  }

  /**
*Getter and setter methods for member variables of class.
*
*/
  
  public String getAdminId() {
    return adminId;
  }

  public void setAdminId(String adminId) {
    this.adminId = adminId;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }
}
