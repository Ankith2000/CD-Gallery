package com.nttdatatraining.dto;

/**
 *
 
 *Member variables of album class.
*/

public class Album {
  private int albumId;
  private String albumTitle;
  private int hirePrice;
  private int numberOfCds;
  private int status;
  private int categoryId;
  
  /**
* Non-parameterized constructor.
*/
  
  public Album() {
    super();
  }

  /**
 *Parameterized constructor.
 */
  
  public Album(int albumId, String albumTitle, int hirePrice, int numberOfCds, 
      int status, int categoryId) {

    super();
    this.albumId = albumId;
    this.albumTitle = albumTitle;
    this.hirePrice = hirePrice;
    this.numberOfCds = numberOfCds;
    this.status = status;
    this.categoryId = categoryId;
  }

  /**
* Getter and setter methods for member variables of class.
*
*/
  
  public int getAlbumId() {
    return albumId;
  }

  public void setAlbumId(int albumId) {
    this.albumId = albumId;
  }

  public String getAlbumTitle() {
    return albumTitle;
  }

  public void setAlbumTitle(String albumTitle) {
    this.albumTitle = albumTitle;
  }

  public int getHirePrice() {
    return hirePrice;
  }

  public void setHirePrice(int hirePrice) {
    this.hirePrice = hirePrice;
  }
  
  public int getNumberOfCds() {
    return numberOfCds;
  }

  public void setNumberOfCds(int numberOfCds) {
    this.numberOfCds = numberOfCds;
  }

  public int getStatus() {
    return status;
  }

  public void setStatus(int status) {
    this.status = status;
  }

  public int getCategoryId() {
    return categoryId;
  }

  public void setCategoryId(int categoryId) {
    this.categoryId = categoryId;
  }
}
