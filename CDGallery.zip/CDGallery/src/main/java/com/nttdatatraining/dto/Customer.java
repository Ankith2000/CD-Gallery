package com.nttdatatraining.dto;

/**
*Creating member variables of customer class.
*/

public class Customer {

  private String customerId;
  private String password;
  private String firstName;
  private String secondName;
  private String dateOfBirth;
  private String address;
  private String contactNumber;
  private String creditCardNumber;
  private String creditCardType;
  private String creditCardExpiry;
  
  /**
*Non-parameterized constructor.
*/
  
  public Customer() {
    super();
  }
  
  /**
*Parameterized constructor.
*/
  
  public Customer(String customerId, String password, String firstName, 
      String secondName, String dateOfBirth, String address, String contactNumber,
      String creditCardNumber, String creditCardType, String creditCardExpiry) {
    super();
    this.customerId = customerId;
    this.password = password;
    this.firstName = firstName;
    this.secondName = secondName;
    this.dateOfBirth = dateOfBirth;
    this.address = address;
    this.contactNumber = contactNumber;
    this.creditCardNumber = creditCardNumber;
    this.creditCardType = creditCardType;
    this.creditCardExpiry = creditCardExpiry;
  }
  
  /**
* Getter and setter methods for member variables.
* 
*/
  
  public String getCustomerId() {
    return customerId;
  }
  
  public void setCustomerId(String customerId) {
    this.customerId = customerId;
  }
  
  public String getPassword() {
    return password;
  }
  
  public void setPassword(String password) {
    this.password = password;
  }
  
  public String getFirstName() {
    return firstName;
  }
  
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }
  
  public String getSecondName() {
    return secondName;
  }
  
  public void setSecondName(String secondName) {
    this.secondName = secondName;
  }
  
  public String getDateOfBirth() {
    return dateOfBirth;
  }
  
  public void setDateOfBirth(String dateOfBirth) {
    this.dateOfBirth = dateOfBirth;
  }
  
  public String getAddress() {
    return address;
  }
  
  public void setAddress(String address) {
    this.address = address;
  }
  
  public String getContactNumber() {
    return contactNumber;
  }
  
  public void setContactNumber(String contactNumber) {
    this.contactNumber = contactNumber;
  }
  
  public String getCreditCardNumber() {
    return creditCardNumber;
  }
  
  public void setCreditCardNumber(String creditCardNumber) {
    this.creditCardNumber = creditCardNumber;
  }
  
  public String getCreditCardType() {
    return creditCardType;
  }
  
  public void setCreditCardType(String creditCardType) {
    this.creditCardType = creditCardType;
  }
  
  public String getCreditCardExpiry() {
    return creditCardExpiry;
  }
  
  public void setCreditCardExpiry(String creditCardExpiry) {
    this.creditCardExpiry = creditCardExpiry;
  }
}
