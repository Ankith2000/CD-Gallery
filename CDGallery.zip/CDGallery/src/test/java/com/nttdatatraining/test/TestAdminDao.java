package com.nttdatatraining.test;

import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

import com.nttdatatraining.dao.AdminDaoImpl;
import com.nttdatatraining.dto.Admin;
import com.nttdatatraining.dto.Album;

public class TestAdminDao {
	AdminDaoImpl adminDao = new AdminDaoImpl();
	
	//Test case to validate the admin credentials. It will give positive result if displayed.
	@Test
	public void testAddNewAdminTrue() {
		Admin admin = new Admin();
		admin.setAdminId("admin");
		admin.setPassword("admin@1234");
		assertTrue(adminDao.adminLogin(admin));
		}
	
	//Test case to validate the admin credentials. It will give negative result if displayed.
	@Test
	public void testAddNewAdminFalse() {
		Admin admin = new Admin();
		admin.setAdminId("admi1n");
		admin.setPassword("admin@1234");
		assertFalse(adminDao.adminLogin(admin));
	}
	
	//Test case to insert an album. It will give negative result if displayed.
	@Test
    public void TestAddNewAlbumFalse() {
       Album album = new Album();
       album.setAlbumTitle("Little Oblivions");
       album.setHirePrice(40);
       album.setNumberOfCds(0);
       album.setStatus(0);
       album.setCategoryId(4);

       assertFalse(adminDao.addAlbum(album));
       }
    
	//Test case to insert an album. It will give positive result if displayed.
    @Test
    public void TestAddNewAlbumTrue() {
    	Album album = new Album();
        album.setAlbumTitle("Done");
        album.setHirePrice(40);
        album.setNumberOfCds(0);
        album.setStatus(0);
        album.setCategoryId(4);
        
      assertTrue(adminDao.addAlbum(album));
    }
    
    @Test
    public void TestViewAllAvailableAlbumTrue() {
        assertNotNull(adminDao.displayAvailableAlbum());
    }
    
    @Test
    public void TestViewAllAvailableAlbumFalse() {
        assertNull(adminDao.displayAvailableAlbum());
    }
    
    @Test
    public void TestdisplayRentalDetailsTrue() {
        assertNotNull(adminDao.displayRentalDetails());
    }
    
    @Test
    public void TestdisplayRentalDetailsFalse() {
        assertNull(adminDao.displayRentalDetails());
    }
    
    
    @Test
    public void TestdisplayAlbumTrue() {
        assertNotNull(adminDao.displayAlbum());
    }
    
    @Test
    public void TestdisplayAlbumFalse() {
        assertNull(adminDao.displayAlbum());
    }
}