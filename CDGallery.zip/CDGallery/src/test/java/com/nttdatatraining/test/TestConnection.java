package com.nttdatatraining.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.sql.SQLException;

import org.junit.Test;

import com.nttdatatraining.connection.DbConnection;

public class TestConnection {

	DbConnection db = new DbConnection();
	@Test
	  public void conPass() throws SQLException {
	    assertNotNull(DbConnection.getDatabaseConnection());
	  }

	  @Test
	  public void conFail() throws SQLException {
	    assertNull(DbConnection.getDatabaseConnection());
	  }
}
