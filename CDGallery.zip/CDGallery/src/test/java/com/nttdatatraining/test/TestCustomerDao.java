package com.nttdatatraining.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.nttdatatraining.dao.CustomerDao;
import com.nttdatatraining.dao.CustomerDaoImpl;
import com.nttdatatraining.dao.DaoException;
import com.nttdatatraining.dto.Customer;
import com.nttdatatraining.dto.RentalDetails;
import com.nttdatatraining.dto.Album;

public class TestCustomerDao {
	CustomerDao customerDao = new CustomerDaoImpl();
	
	// Test case to validate customer login. It will give positive result if customer login is successful.
	@Test
    public void validateCustomerLoginTrue() throws DaoException {
		Customer customer = new Customer();
		boolean status = true;


		customer.setCustomerId("C001");
		customer.setPassword("abcd");
		assertEquals(status,customerDao.customerLogin(customer));
    }
	
	// Test case to validate customer login. It will give negative result if customer login is unsuccessful.
	@Test
    public void validateCustomerLoginFalse() throws DaoException {
		Customer customer = new Customer();
		boolean status = false;


		customer.setCustomerId("C001");
		customer.setPassword("abcdsd");
		assertEquals(status,customerDao.customerLogin(customer));
		} 

	// Test case to check if album is present. It will give positive result if album is present.
	@Test
	public void testBookAlbumTrue() throws DaoException {

		CustomerDao dao = new CustomerDaoImpl();
		Customer cust = new Customer();
		Album album = new Album();
		cust.setCustomerId("C002");
		album.setAlbumId(1);
		boolean status = true;
		assertEquals(status, dao.bookAlbum(cust,album));
	}
	
	@Test
	public void testBookAlbumFalse() throws DaoException {

		CustomerDao dao = new CustomerDaoImpl();
		Customer cust = new Customer();
		Album album = new Album();
		cust.setCustomerId("C016");
		album.setAlbumId(78);
		boolean status = false;
		assertEquals(status, dao.bookAlbum(cust,album));
	}
	
	@Test
    public void addNewCustomerTrue() throws DaoException {
	 Customer customer = new Customer();
	 customer.setCustomerId("C013");
     customer.setPassword("bruno123");
     customer.setFirstName("Bruno");
     customer.setSecondName("Fernandes");
	 customer.setDateOfBirth("2000-08-08");
	 customer.setAddress("Bengaluru");
     customer.setContactNumber("9873456578");
     customer.setCreditCardNumber("124356878909");
     customer.setCreditCardType("Platinum");
     customer.setCreditCardExpiry("09/26");

     assertTrue(customerDao.addCustomer(customer));
    }
	
	@Test
	public void testviewBookedAlbumFalse() throws DaoException
	{
		CustomerDao dao = new CustomerDaoImpl();
		Customer cust = new Customer();
		RentalDetails rental = new RentalDetails();
		cust.setCustomerId("C002");
		rental.setStatus("Yes");
		List<RentalDetails> list = dao.viewBookedAlbum(cust,rental);
		List<RentalDetails> check = new ArrayList<>();
		RentalDetails ren = new RentalDetails(1, "C002", 1, 6, "2021-10-15", "2021-10-15", "Yes", 360);
		check.add(ren);
		assertEquals(ren,list);
	}
	
	
	@Test
	public void testviewsearchAlbumFalse() throws DaoException
	{
		CustomerDao dao = new CustomerDaoImpl();
		Album album = new Album();
		album.setAlbumId(1);
		List<Album> list = dao.searchAlbum(album);
		List<Album> check = new ArrayList<>();
		Album alb = new Album(1, "Thriller", 60, 19, 1, 1);
		check.add(alb);
		assertEquals(alb,list);
	}
	
  }